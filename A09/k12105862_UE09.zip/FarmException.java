public class FarmException extends Exception {
    public FarmException(String msg) {
        super(msg);
    }
}
