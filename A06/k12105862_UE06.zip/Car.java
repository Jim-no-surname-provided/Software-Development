public class Car {
    String name  = "Unknown car type";
    double speed =  60;
    double distance  = 0;
}
