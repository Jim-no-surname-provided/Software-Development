public class Statistics {
    String smallestString;
    int amountStrings;
    double lengthMean;
    char[] firstLetters;
}
